document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('token');
  if (!token) {
    window.location.href = '/login.html';
    return;
  }

  const patientsTable = document.getElementById('patientsTable');
  const addPatientButton = document.getElementById('addPatientButton');
  const patientModal = new bootstrap.Modal(document.getElementById('patientModal'));
  const patientForm = document.getElementById('patientForm');
  const savePatientButton = document.getElementById('savePatientButton');

  // Загрузка данных пациентов
  const loadPatients = async () => {
    try {
      const response = await fetch('/api/patients', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const patients = await response.json();

      patientsTable.innerHTML = patients
        .map(
          (patient) => `
          <tr>
            <td>${patient.fullname}</td>
            <td>${patient.birthdate}</td>
            <td>${patient.gender}</td>
            <td>${patient.address}</td>
            <td>${patient.phone}</td>
            <td>${patient.email}</td>
            <td>
              <button class="btn btn-warning btn-sm edit-patient" data-id="${patient.patientid}">Редактировать</button>
              <button class="btn btn-danger btn-sm delete-patient" data-id="${patient.patientid}">Удалить</button>
            </td>
          </tr>
        `
        )
        .join('');
    } catch (err) {
      console.error('Ошибка загрузки данных:', err);
    }
  };

  // Открытие модального окна для добавления пациента
  addPatientButton.addEventListener('click', () => {
    patientForm.reset();
    patientModal.show();
  });

  // Сохранение пациента (добавление/редактирование)
  savePatientButton.addEventListener('click', async () => {
    const patientId = document.getElementById('patientId').value;
    const fullname = document.getElementById('fullname').value;
    const birthdate = document.getElementById('birthdate').value;
    const gender = document.getElementById('gender').value;
    const address = document.getElementById('address').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;

    const url = patientId ? `/api/patients/${patientId}` : '/api/patients';
    const method = patientId ? 'PUT' : 'POST';

    try {
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ fullname, birthdate, gender, address, phone, email }),
      });

      if (response.ok) {
        patientModal.hide();
        loadPatients();
      }
    } catch (err) {
      console.error('Ошибка сохранения пациента:', err);
    }
  });

  // Редактирование пациента
  patientsTable.addEventListener('click', async (e) => {
    if (e.target.classList.contains('edit-patient')) {
      const patientId = e.target.getAttribute('data-id');

      try {
        const response = await fetch(`/api/patients/${patientId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        const patient = await response.json();

        document.getElementById('patientId').value = patient.patientid;
        document.getElementById('fullname').value = patient.fullname;
        document.getElementById('birthdate').value = patient.birthdate;
        document.getElementById('gender').value = patient.gender;
        document.getElementById('address').value = patient.address;
        document.getElementById('phone').value = patient.phone;
        document.getElementById('email').value = patient.email;

        patientModal.show();
      } catch (err) {
        console.error('Ошибка загрузки данных пациента:', err);
      }
    }
  });

  // Удаление пациента
  patientsTable.addEventListener('click', async (e) => {
    if (e.target.classList.contains('delete-patient')) {
      const patientId = e.target.getAttribute('data-id');

      try {
        const response = await fetch(`/api/patients/${patientId}`, {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.ok) {
          loadPatients();
        }
      } catch (err) {
        console.error('Ошибка удаления пациента:', err);
      }
    }
  });

  // Загрузка данных при открытии страницы
  loadPatients();
});