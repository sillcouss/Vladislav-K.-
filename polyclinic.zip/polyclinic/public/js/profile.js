document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('token');

  if (!token) {
    window.location.href = '/login.html';
    return;
  }

  const userInfo = document.getElementById('userInfo');
  const logoutButton = document.getElementById('logoutButton');
  const editProfileButton = document.getElementById('editProfileButton');
  const editProfileModal = new bootstrap.Modal(document.getElementById('editProfileModal'));
  const editProfileForm = document.getElementById('editProfileForm');
  const saveProfileButton = document.getElementById('saveProfileButton');
  const usernameInput = document.getElementById('username');
  const fullnameInput = document.getElementById('fullname');
  const emailInput = document.getElementById('email');
  const phoneInput = document.getElementById('phone');

  let currentUser = null;

  // Получаем данные пользователя
  const loadUserProfile = async () => {
    try {
      const response = await fetch('/api/auth/me', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        currentUser = await response.json();
        userInfo.innerHTML = `
          <strong>Логин:</strong> ${currentUser.username}<br>
          <strong>ФИО:</strong> ${currentUser.fullname || 'Не указано'}<br>
          <strong>Email:</strong> ${currentUser.email || 'Не указано'}<br>
          <strong>Телефон:</strong> ${currentUser.phone || 'Не указано'}
        `;
      } else {
        userInfo.innerHTML = 'Ошибка загрузки данных пользователя';
      }
    } catch (err) {
      console.error('Ошибка загрузки данных пользователя:', err);
      userInfo.innerHTML = 'Ошибка загрузки данных пользователя';
    }
  };

  // Открытие модального окна для редактирования профиля
  editProfileButton.addEventListener('click', () => {
    if (currentUser) {
      usernameInput.value = currentUser.username;
      fullnameInput.value = currentUser.fullname || '';
      emailInput.value = currentUser.email || '';
      phoneInput.value = currentUser.phone || '';
      editProfileModal.show();
    }
  });

  // Сохранение изменений профиля
  saveProfileButton.addEventListener('click', async () => {
    const updatedData = {
      username: usernameInput.value,
      fullname: fullnameInput.value,
      email: emailInput.value,
      phone: phoneInput.value,
    };

    try {
      const response = await fetch('/api/auth/update-profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updatedData),
      });

      if (response.ok) {
        editProfileModal.hide();
        await loadUserProfile(); // Перезагружаем данные профиля
      } else {
        alert('Ошибка при обновлении профиля');
      }
    } catch (err) {
      console.error('Ошибка при обновлении профиля:', err);
      alert('Ошибка при обновлении профиля');
    }
  });

  // Обработка выхода
  logoutButton.addEventListener('click', async () => {
    localStorage.removeItem('token');
    window.location.href = '/login.html';
  });

  // Загружаем данные профиля при открытии страницы
  await loadUserProfile();
});