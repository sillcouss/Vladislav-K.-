document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('token');
  
    if (!token) {
      window.location.href = '/login.html';
    }
  
    document.getElementById('logoutButton').addEventListener('click', async () => {
      localStorage.removeItem('token'); // Удаляем токен
      window.location.href = '/login.html';
    });
  });