document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      window.location.href = '/login.html';
      return;
    }
  
    const appointmentsTable = document.getElementById('appointmentsTable');
    const addAppointmentButton = document.getElementById('addAppointmentButton');
    const appointmentModal = new bootstrap.Modal(document.getElementById('appointmentModal'));
    const appointmentForm = document.getElementById('appointmentForm');
    const saveAppointmentButton = document.getElementById('saveAppointmentButton');
    const patientSelect = document.getElementById('patientId');
    const doctorSelect = document.getElementById('doctorId');
  
    // Загрузка данных пациентов и врачей
    const loadPatientsAndDoctors = async () => {
      try {
        const [patientsResponse, doctorsResponse] = await Promise.all([
          fetch('/api/patients', {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }),
          fetch('/api/doctors', {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }),
        ]);
  
        const patients = await patientsResponse.json();
        const doctors = await doctorsResponse.json();
  
        patientSelect.innerHTML = patients
          .map((patient) => `<option value="${patient.patientid}">${patient.fullname}</option>`)
          .join('');
  
        doctorSelect.innerHTML = doctors
          .map((doctor) => `<option value="${doctor.doctorid}">${doctor.fullname}</option>`)
          .join('');
      } catch (err) {
        console.error('Ошибка загрузки данных:', err);
      }
    };
  
    // Загрузка данных записей на прием
    const loadAppointments = async () => {
      try {
        const response = await fetch('/api/appointments', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        const appointments = await response.json();
  
        appointmentsTable.innerHTML = appointments
          .map(
            (appointment) => `
            <tr>
              <td>${appointment.patientid}</td>
              <td>${appointment.doctorid}</td>
              <td>${appointment.appointmentdate}</td>
              <td>${appointment.status}</td>
              <td>
                <button class="btn btn-warning btn-sm edit-appointment" data-id="${appointment.appointmentid}">Редактировать</button>
                <button class="btn btn-danger btn-sm delete-appointment" data-id="${appointment.appointmentid}">Удалить</button>
              </td>
            </tr>
          `
          )
          .join('');
      } catch (err) {
        console.error('Ошибка загрузки данных:', err);
      }
    };
  
    // Открытие модального окна для добавления записи
    addAppointmentButton.addEventListener('click', () => {
      appointmentForm.reset();
      appointmentModal.show();
    });
  
    // Сохранение записи (добавление/редактирование)
    saveAppointmentButton.addEventListener('click', async () => {
      const appointmentId = document.getElementById('appointmentId').value;
      const patientId = document.getElementById('patientId').value;
      const doctorId = document.getElementById('doctorId').value;
      const appointmentDate = document.getElementById('appointmentDate').value;
      const status = document.getElementById('status').value;
  
      const url = appointmentId ? `/api/appointments/${appointmentId}` : '/api/appointments';
      const method = appointmentId ? 'PUT' : 'POST';
  
      try {
        const response = await fetch(url, {
          method,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ patientId, doctorId, appointmentDate, status }),
        });
  
        if (response.ok) {
          appointmentModal.hide();
          loadAppointments();
        }
      } catch (err) {
        console.error('Ошибка сохранения записи:', err);
      }
    });
  
    // Редактирование записи
    appointmentsTable.addEventListener('click', async (e) => {
      if (e.target.classList.contains('edit-appointment')) {
        const appointmentId = e.target.getAttribute('data-id');
  
        try {
          const response = await fetch(`/api/appointments/${appointmentId}`, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          const appointment = await response.json();
  
          document.getElementById('appointmentId').value = appointment.appointmentid;
          document.getElementById('patientId').value = appointment.patientid;
          document.getElementById('doctorId').value = appointment.doctorid;
          document.getElementById('appointmentDate').value = appointment.appointmentdate;
          document.getElementById('status').value = appointment.status;
  
          appointmentModal.show();
        } catch (err) {
          console.error('Ошибка загрузки данных записи:', err);
        }
      }
    });
  
    // Удаление записи
    appointmentsTable.addEventListener('click', async (e) => {
      if (e.target.classList.contains('delete-appointment')) {
        const appointmentId = e.target.getAttribute('data-id');
  
        try {
          const response = await fetch(`/api/appointments/${appointmentId}`, {
            method: 'DELETE',
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
  
          if (response.ok) {
            loadAppointments();
          }
        } catch (err) {
          console.error('Ошибка удаления записи:', err);
        }
      }
    });
  
    // Загрузка данных при открытии страницы
    loadPatientsAndDoctors();
    loadAppointments();
  });