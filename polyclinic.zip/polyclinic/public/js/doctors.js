document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      window.location.href = '/login.html';
      return;
    }
  
    const doctorsTable = document.getElementById('doctorsTable');
    const addDoctorButton = document.getElementById('addDoctorButton');
    const doctorModal = new bootstrap.Modal(document.getElementById('doctorModal'));
    const doctorForm = document.getElementById('doctorForm');
    const saveDoctorButton = document.getElementById('saveDoctorButton');
  
    // Загрузка данных врачей
    const loadDoctors = async () => {
      try {
        const response = await fetch('/api/doctors', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        const doctors = await response.json();
  
        doctorsTable.innerHTML = doctors
          .map(
            (doctor) => `
            <tr>
              <td>${doctor.fullname}</td>
              <td>${doctor.specialization}</td>
              <td>${doctor.phone}</td>
              <td>${doctor.email}</td>
              <td>
                <button class="btn btn-warning btn-sm edit-doctor" data-id="${doctor.doctorid}">Редактировать</button>
                <button class="btn btn-danger btn-sm delete-doctor" data-id="${doctor.doctorid}">Удалить</button>
              </td>
            </tr>
          `
          )
          .join('');
      } catch (err) {
        console.error('Ошибка загрузки данных:', err);
      }
    };
  
    // Открытие модального окна для добавления врача
    addDoctorButton.addEventListener('click', () => {
      doctorForm.reset();
      doctorModal.show();
    });
  
    // Сохранение врача (добавление/редактирование)
    saveDoctorButton.addEventListener('click', async () => {
      const doctorId = document.getElementById('doctorId').value;
      const fullname = document.getElementById('fullname').value;
      const specialization = document.getElementById('specialization').value;
      const phone = document.getElementById('phone').value;
      const email = document.getElementById('email').value;
  
      const url = doctorId ? `/api/doctors/${doctorId}` : '/api/doctors';
      const method = doctorId ? 'PUT' : 'POST';
  
      try {
        const response = await fetch(url, {
          method,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ fullname, specialization, phone, email }),
        });
  
        if (response.ok) {
          doctorModal.hide();
          loadDoctors();
        }
      } catch (err) {
        console.error('Ошибка сохранения врача:', err);
      }
    });
  
    // Редактирование врача
    doctorsTable.addEventListener('click', async (e) => {
      if (e.target.classList.contains('edit-doctor')) {
        const doctorId = e.target.getAttribute('data-id');
  
        try {
          const response = await fetch(`/api/doctors/${doctorId}`, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          const doctor = await response.json();
  
          document.getElementById('doctorId').value = doctor.doctorid;
          document.getElementById('fullname').value = doctor.fullname;
          document.getElementById('specialization').value = doctor.specialization;
          document.getElementById('phone').value = doctor.phone;
          document.getElementById('email').value = doctor.email;
  
          doctorModal.show();
        } catch (err) {
          console.error('Ошибка загрузки данных врача:', err);
        }
      }
    });
  
    // Удаление врача
    doctorsTable.addEventListener('click', async (e) => {
      if (e.target.classList.contains('delete-doctor')) {
        const doctorId = e.target.getAttribute('data-id');
  
        try {
          const response = await fetch(`/api/doctors/${doctorId}`, {
            method: 'DELETE',
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
  
          if (response.ok) {
            loadDoctors();
          }
        } catch (err) {
          console.error('Ошибка удаления врача:', err);
        }
      }
    });
  
    // Загрузка данных при открытии страницы
    loadDoctors();
  });