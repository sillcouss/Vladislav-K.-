const { Pool } = require('pg');
const bcrypt = require('bcrypt');

// Настройки подключения к базе данных
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: '1234',
  database: 'polyclinic_db',
});

// Данные администратора
const adminData = {
  username: 'admin1',
  password: '1234', // Пароль администратора
  role: 'admin',
};

// Функция для создания администратора
const createAdmin = async () => {
  try {
    // Проверяем, существует ли уже пользователь с таким логином
    const { rows } = await pool.query('SELECT * FROM Users WHERE Username = $1', [adminData.username]);

    if (rows.length > 0) {
      console.log('Пользователь с таким логином уже существует:', rows[0]);
      return;
    }

    // Хэшируем пароль
    const hashedPassword = await bcrypt.hash(adminData.password, 10);

    // Добавляем администратора в базу данных
    const result = await pool.query(
      'INSERT INTO Users (Username, PasswordHash, Role) VALUES ($1, $2, $3) RETURNING *',
      [adminData.username, hashedPassword, adminData.role]
    );

    console.log('Администратор успешно создан:', result.rows[0]);
  } catch (err) {
    console.error('Ошибка при создании администратора:', err);
  } finally {
    // Закрываем соединение с базой данных
    await pool.end();
  }
};

// Запуск функции
createAdmin();