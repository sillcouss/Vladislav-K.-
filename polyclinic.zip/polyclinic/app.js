const express = require('express');
const patientRoutes = require('./src/routes/patientRoutes'); // Маршруты для пациентов
const doctorRoutes = require('./src/routes/doctorRoutes'); // Маршруты для врачей
const appointmentRoutes = require('./src/routes/appointmentRoutes'); // Маршруты для записей на прием
const authRoutes = require('./src/routes/authRoutes'); // Маршруты для авторизации
const jwt = require('jsonwebtoken'); // Для работы с JWT
const pool = require('./src/db/db'); // Подключение к базе данных
const bcrypt = require('bcrypt'); // Для хэширования паролей

const app = express();
app.use(express.json()); // Для обработки JSON-запросов
app.use(express.static('public')); // Для обслуживания статических файлов

// Middleware для CORS (если нужно)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  next();
});

// Middleware для проверки JWT-токена
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Получаем токен из заголовка

  if (!token) {
    return res.status(401).json({ message: 'Токен отсутствует' });
  }

  // Проверяем токен
  jwt.verify(token, 'secret_key', (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Недействительный токен' });
    }
    req.user = user; // Сохраняем данные пользователя в запросе
    next();
  });
};

// Регистрация нового пользователя
app.post('/api/auth/register', async (req, res) => {
  const { username, password, role, fullname, email, phone } = req.body;

  try {
    // Хэшируем пароль
    const hashedPassword = await bcrypt.hash(password, 10);

    // Сохраняем пользователя в базу данных
    const { rows } = await pool.query(
      'INSERT INTO Users (Username, PasswordHash, Role, FullName, Email, Phone) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
      [username, hashedPassword, role, fullname, email, phone]
    );

    res.status(201).json({ message: 'Пользователь зарегистрирован', user: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка регистрации');
  }
});

// Авторизация пользователя
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Ищем пользователя в базе данных
    const { rows } = await pool.query('SELECT * FROM Users WHERE Username = $1', [username]);

    if (rows.length === 0) {
      return res.status(401).json({ message: 'Неверный логин или пароль' });
    }

    const user = rows[0];

    // Проверяем пароль
    const isPasswordValid = await bcrypt.compare(password, user.passwordhash);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Неверный логин или пароль' });
    }

    // Создаем JWT-токен
    const token = jwt.sign({ userId: user.userid, role: user.role }, 'secret_key', { expiresIn: '1h' });

    res.json({ message: 'Авторизация успешна', token });
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка авторизации');
  }
});

// Получение данных текущего пользователя
app.get('/api/auth/me', authenticateToken, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM Users WHERE UserId = $1', [req.user.userId]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    const user = rows[0];
    res.json({ username: user.username, role: user.role, fullname: user.fullname, email: user.email, phone: user.phone });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Ошибка загрузки данных пользователя' });
  }
});

// Обновление профиля пользователя
app.put('/api/auth/update-profile', authenticateToken, async (req, res) => {
  const { username, fullname, email, phone } = req.body;
  const userId = req.user.userId;

  try {
    const { rows } = await pool.query(
      'UPDATE Users SET Username = $1, FullName = $2, Email = $3, Phone = $4 WHERE UserId = $5 RETURNING *',
      [username, fullname, email, phone, userId]
    );

    res.json({ message: 'Профиль обновлен', user: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Ошибка обновления профиля' });
  }
});

// Выход пользователя
app.post('/api/auth/logout', (req, res) => {
  res.json({ message: 'Выход выполнен' });
});

// Подключение маршрутов с проверкой авторизации
app.use('/api/patients', authenticateToken, patientRoutes);
app.use('/api/doctors', authenticateToken, doctorRoutes);
app.use('/api/appointments', authenticateToken, appointmentRoutes);

// Маршруты для авторизации (без проверки токена)
app.use('/api/auth', authRoutes);

// Обработка ошибки 404 (маршрут не найден)
app.use((req, res) => {
  res.status(404).json({ message: 'Маршрут не найден' });
});

// Обработка ошибок сервера
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Ошибка сервера' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});