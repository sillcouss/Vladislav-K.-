const express = require('express');
const {
  getAppointments,
  getAppointmentById,
  addAppointment,
  updateAppointment,
  deleteAppointment,
} = require('../controllers/appointmentController');

const router = express.Router();

// Получить все записи на прием
router.get('/', getAppointments);

// Получить запись на прием по ID
router.get('/:id', getAppointmentById);

// Добавить новую запись на прием
router.post('/', addAppointment);

// Обновить запись на прием
router.put('/:id', updateAppointment);

// Удалить запись на прием
router.delete('/:id', deleteAppointment);

module.exports = router;