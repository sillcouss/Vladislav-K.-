const express = require('express');
const {
  getPatients,
  getPatientById,
  addPatient,
  updatePatient,
  deletePatient,
} = require('../controllers/patientController');

const router = express.Router();

// Получить всех пациентов
router.get('/', getPatients);

// Получить пациента по ID
router.get('/:id', getPatientById);

// Добавить нового пациента
router.post('/', addPatient);

// Обновить данные пациента
router.put('/:id', updatePatient);

// Удалить пациента
router.delete('/:id', deletePatient);

module.exports = router;