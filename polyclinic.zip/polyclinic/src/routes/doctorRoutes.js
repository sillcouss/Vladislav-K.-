const express = require('express');
const {
  getDoctors,
  getDoctorById,
  addDoctor,
  updateDoctor,
  deleteDoctor,
} = require('../controllers/doctorController');

const router = express.Router();

// Получить всех врачей
router.get('/', getDoctors);

// Получить врача по ID
router.get('/:id', getDoctorById);

// Добавить нового врача
router.post('/', addDoctor);

// Обновить данные врача
router.put('/:id', updateDoctor);

// Удалить врача
router.delete('/:id', deleteDoctor);

module.exports = router;