const express = require('express');
const { register, login, logout } = require('../controllers/authController');

const router = express.Router();

// Регистрация нового пользователя
router.post('/register', register);

// Авторизация пользователя
router.post('/login', login);

// Выход пользователя
router.post('/logout', logout);

module.exports = router;