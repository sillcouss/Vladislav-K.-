const pool = require('../db/db');

// Получить все записи на прием
const getAppointments = async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM Appointments');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка загрузки записей на прием');
  }
};

// Получить запись на прием по ID
const getAppointmentById = async (req, res) => {
  const { id } = req.params;

  try {
    const { rows } = await pool.query('SELECT * FROM Appointments WHERE AppointmentID = $1', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Запись на прием не найдена' });
    }

    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка загрузки записи на прием');
  }
};

// Добавить новую запись на прием
const addAppointment = async (req, res) => {
  const { patientId, doctorId, appointmentDate, status } = req.body;

  try {
    const { rows } = await pool.query(
      'INSERT INTO Appointments (PatientID, DoctorID, AppointmentDate, Status) VALUES ($1, $2, $3, $4) RETURNING *',
      [patientId, doctorId, appointmentDate, status]
    );

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка добавления записи на прием');
  }
};

// Обновить запись на прием
const updateAppointment = async (req, res) => {
  const { id } = req.params;
  const { patientId, doctorId, appointmentDate, status } = req.body;

  try {
    const { rows } = await pool.query(
      'UPDATE Appointments SET PatientID = $1, DoctorID = $2, AppointmentDate = $3, Status = $4 WHERE AppointmentID = $5 RETURNING *',
      [patientId, doctorId, appointmentDate, status, id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Запись на прием не найдена' });
    }

    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка обновления записи на прием');
  }
};

// Удалить запись на прием
const deleteAppointment = async (req, res) => {
  const { id } = req.params;

  try {
    const { rows } = await pool.query('DELETE FROM Appointments WHERE AppointmentID = $1 RETURNING *', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Запись на прием не найдена' });
    }

    res.json({ message: 'Запись на прием удалена' });
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка удаления записи на прием');
  }
};

module.exports = {
  getAppointments,
  getAppointmentById,
  addAppointment,
  updateAppointment,
  deleteAppointment,
};