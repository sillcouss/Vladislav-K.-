const pool = require('../db/db');

// Получить всех врачей
const getDoctors = async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM Doctors');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка загрузки врачей');
  }
};

// Получить врача по ID
const getDoctorById = async (req, res) => {
  const { id } = req.params;

  try {
    const { rows } = await pool.query('SELECT * FROM Doctors WHERE DoctorID = $1', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Врач не найден' });
    }

    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка загрузки врача');
  }
};

// Добавить нового врача
const addDoctor = async (req, res) => {
  const { fullname, specialization, phone, email } = req.body;

  try {
    const { rows } = await pool.query(
      'INSERT INTO Doctors (FullName, Specialization, Phone, Email) VALUES ($1, $2, $3, $4) RETURNING *',
      [fullname, specialization, phone, email]
    );

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка добавления врача');
  }
};

// Обновить данные врача
const updateDoctor = async (req, res) => {
  const { id } = req.params;
  const { fullname, specialization, phone, email } = req.body;

  try {
    const { rows } = await pool.query(
      'UPDATE Doctors SET FullName = $1, Specialization = $2, Phone = $3, Email = $4 WHERE DoctorID = $5 RETURNING *',
      [fullname, specialization, phone, email, id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Врач не найден' });
    }

    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка обновления врача');
  }
};

// Удалить врача
const deleteDoctor = async (req, res) => {
  const { id } = req.params;

  try {
    const { rows } = await pool.query('DELETE FROM Doctors WHERE DoctorID = $1 RETURNING *', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Врач не найден' });
    }

    res.json({ message: 'Врач удален' });
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка удаления врача');
  }
};

module.exports = {
  getDoctors,
  getDoctorById,
  addDoctor,
  updateDoctor,
  deleteDoctor,
};