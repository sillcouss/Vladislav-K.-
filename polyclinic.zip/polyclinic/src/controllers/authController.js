const pool = require('../db/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Регистрация нового пользователя
const register = async (req, res) => {
  const { username, password, role } = req.body;

  try {
    // Хэшируем пароль
    const hashedPassword = await bcrypt.hash(password, 10);

    // Сохраняем пользователя в базу данных
    const { rows } = await pool.query(
      'INSERT INTO Users (Username, PasswordHash, Role) VALUES ($1, $2, $3) RETURNING *',
      [username, hashedPassword, role]
    );

    res.status(201).json({ message: 'Пользователь зарегистрирован', user: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка регистрации');
  }
};

// Авторизация пользователя
const login = async (req, res) => {
  const { username, password } = req.body;

  try {
    // Ищем пользователя в базе данных
    const { rows } = await pool.query('SELECT * FROM Users WHERE Username = $1', [username]);

    if (rows.length === 0) {
      return res.status(401).json({ message: 'Неверный логин или пароль' });
    }

    const user = rows[0];

    // Проверяем пароль
    const isPasswordValid = await bcrypt.compare(password, user.passwordhash);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Неверный логин или пароль' });
    }

    // Создаем JWT-токен
    const token = jwt.sign({ userId: user.userid, role: user.role }, 'secret_key', { expiresIn: '1h' });

    res.json({ message: 'Авторизация успешна', token });
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка авторизации');
  }
};

// Выход пользователя (просто удаляем токен на клиенте)
const logout = (req, res) => {
  res.json({ message: 'Выход выполнен' });
};

module.exports = { register, login, logout };