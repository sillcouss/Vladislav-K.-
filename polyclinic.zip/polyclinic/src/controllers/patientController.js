const pool = require('../db/db');

// Получить всех пациентов
const getPatients = async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM Patients');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка загрузки пациентов');
  }
};

// Получить пациента по ID
const getPatientById = async (req, res) => {
  const { id } = req.params;

  try {
    const { rows } = await pool.query('SELECT * FROM Patients WHERE PatientID = $1', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Пациент не найден' });
    }

    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка загрузки пациента');
  }
};

// Добавить нового пациента
const addPatient = async (req, res) => {
  const { fullname, birthdate, gender, address, phone, email } = req.body;

  try {
    const { rows } = await pool.query(
      'INSERT INTO Patients (FullName, BirthDate, Gender, Address, Phone, Email) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
      [fullname, birthdate, gender, address, phone, email]
    );

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка добавления пациента');
  }
};

// Обновить данные пациента
const updatePatient = async (req, res) => {
  const { id } = req.params;
  const { fullname, birthdate, gender, address, phone, email } = req.body;

  try {
    const { rows } = await pool.query(
      'UPDATE Patients SET FullName = $1, BirthDate = $2, Gender = $3, Address = $4, Phone = $5, Email = $6 WHERE PatientID = $7 RETURNING *',
      [fullname, birthdate, gender, address, phone, email, id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Пациент не найден' });
    }

    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка обновления пациента');
  }
};

// Удалить пациента
const deletePatient = async (req, res) => {
  const { id } = req.params;

  try {
    const { rows } = await pool.query('DELETE FROM Patients WHERE PatientID = $1 RETURNING *', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'Пациент не найден' });
    }

    res.json({ message: 'Пациент удален' });
  } catch (err) {
    console.error(err);
    res.status(500).send('Ошибка удаления пациента');
  }
};

module.exports = {
  getPatients,
  getPatientById,
  addPatient,
  updatePatient,
  deletePatient,
};